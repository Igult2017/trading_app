# Trading Signals Dashboard | Alpha Terminal

## Overview

A full-stack trading signals dashboard application built with React frontend and Express backend. The project appears to be designed for displaying trading signals and market data with a terminal-style interface featuring a dark theme with grid backgrounds.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight React router)
- **State Management**: TanStack React Query for server state
- **Styling**: Tailwind CSS with CSS variables for theming
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Build Tool**: Vite with hot module replacement

The frontend follows a component-based architecture with:
- Path aliases configured (`@/` for client/src, `@shared/` for shared code)
- Comprehensive UI component library in `client/src/components/ui/`
- Custom hooks for mobile detection and toast notifications
- API request utilities with React Query integration

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **HTTP Server**: Node.js native HTTP server
- **Development**: Vite dev server integration for HMR

The backend follows a modular structure:
- `server/index.ts`: Main entry point with middleware setup
- `server/routes.ts`: API route definitions (prefixed with `/api`)
- `server/storage.ts`: Data access layer with interface abstraction
- `server/static.ts`: Static file serving for production
- `server/vite.ts`: Vite integration for development

### Data Storage
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Schema Location**: `shared/schema.ts` (shared between frontend and backend)
- **Current Implementation**: In-memory storage (`MemStorage` class) with interface for future database migration
- **Validation**: Zod schemas generated from Drizzle schemas via drizzle-zod

### Build System
- **Development**: `tsx` for running TypeScript directly
- **Production Build**: Custom build script using esbuild for server and Vite for client
- **Output**: `dist/` directory with bundled server (`index.cjs`) and static client files (`public/`)

## External Dependencies

### Database
- **PostgreSQL**: Configured via `DATABASE_URL` environment variable
- **Session Store**: `connect-pg-simple` for PostgreSQL-backed sessions

### Key Libraries
- **Drizzle Kit**: Database migrations and schema management
- **React Day Picker**: Calendar component functionality
- **Embla Carousel**: Carousel component
- **Recharts**: Chart/data visualization components
- **Lucide React**: Icon library
- **class-variance-authority**: Component variant management
- **Vaul**: Drawer component primitives

### Fonts
- **Montserrat**: Primary application font
- **IBM Plex Mono**: Monospace font for terminal-style elements

### Development Tools
- Replit-specific Vite plugins for development experience
- PostCSS with Autoprefixer for CSS processing