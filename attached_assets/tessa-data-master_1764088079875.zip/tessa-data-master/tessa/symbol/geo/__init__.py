"""Geography helpers for `ExtendedSymbol`."""

from .countrynames import CountryName
from . import jurisdiction2region as j2r
