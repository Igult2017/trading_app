

def get_emoji(pair):
    if pair == "USD":
        return "🇺🇸"
    elif pair == "EUR":
        return "🇪🇺"
    elif pair == "GBP":
        return "🇬🇧"
    elif pair == "CAD":
        return "🇨🇦"
    elif pair == "CNY":
        return "🇨🇳"
    elif pair == "JPY":
        return "🇯🇵"
    elif pair == "CHF":
        return "🇨🇭"
    elif pair == "AUD":
        return "🇦🇺"
    